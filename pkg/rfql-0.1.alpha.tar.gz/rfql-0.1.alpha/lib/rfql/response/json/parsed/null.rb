module RFQL
  module Response
    class JSON
      class Parsed
        class Null < NilClass; end
      end
    end
  end
end
